<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>recovery</title>
    <link rel="stylesheet" href="style.css?v=<?php echo time(); ?>">
</head>
<body>
    <div class="main_div">
        <form action="<?php echo htmlentities($_SERVER['PHP_SELF']);?>" method="POST" >
        <?php
include 'connection.php';
include('smtp/PHPMailerAutoload.php');
if(isset($_POST['submit'])){
    $email = $_POST['email'];

    //email validation
    $checkemail = "select * from demodata where email='$email'";
    $emailquery = mysqli_query($con, $checkemail);
    $emailcount = mysqli_num_rows($emailquery);

    if($emailcount > 0){
        $emaildata = mysqli_fetch_array($emailquery);
        $username = $emaildata['name'];
        $token = $emaildata['token'];
                    $subject = "Account Recovery";
                    $body = "hi $username, click the link to recover your account http://localhost/reset.php?token=$token";
                    $mail = new PHPMailer(); 
                    //$mail->SMTPDebug=3;
                    $mail->IsSMTP(); 
                    $mail->SMTPAuth = true; 
                    $mail->SMTPSecure = 'SSL'; 
                    $mail->Host = "smtp.gmail.com";
                    $mail->Port = "587"; 
                    $mail->IsHTML(true);
                    $mail->CharSet = 'UTF-8';
                    $mail->Username = "ds2357196@gmail.com";
                    $mail->Password = 'pelgkpjhreqzbnot';
                    $mail->SetFrom("email");
                    $mail->Subject = $subject;
                    $mail->Body =$body;
                    $mail->AddAddress($email);
                    $mail->SMTPOptions=array('ssl'=>array(
                      'verify_peer'=>false,
                      'verify_peer_name'=>false,
                      'allow_self_signed'=>false
                    ));

                    if($mail->Send()){
                        $_SESSION['msg'] = "check your email $email to recover your account";
                        ?>
                         <script>
                            location.replace("login.php");
                         </script>
                        <?php
                    }else{
                        $_SESSION['msg'] = "mail doesn't send"; 
                    }
    }else{
        ?>
          <script>
            alert("invalid email");
          </script>
        <?php
    }
}
?>
            <div class="box">
                <div class="heading">
                    <h2 class="recovery">Account recovery</h2>
                </div>
                <div class="sub_head">
                    <p>enter the email of your account</p>
                </div> 
                <div class="grp_div">
                    <input type="text" name="email" placeholder="email" autocomplete="off" required >
                </div>
                <input type="submit" value="send" name="submit">
            </div>
        </form>
    </div>
</body>
</html>