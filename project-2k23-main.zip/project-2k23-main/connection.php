<?php

   $username = 'root';
   $password = '';
   $server = 'localhost';
   $db =    'demo_db';

   $con = mysqli_connect($server,$username,$password,$db);

?>