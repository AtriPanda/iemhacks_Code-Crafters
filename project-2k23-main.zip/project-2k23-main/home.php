<?php
session_start();
if (!isset($_SESSION['name'])) {
    header('location:login.php');
}

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo "home/".$_SESSION['name'] ?></title>
    <link rel="stylesheet" href="01.css?v=<?php echo time(); ?>">
    <link rel="icon" type="images/webp" href="p5.webp">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>

<body>
    <div class="main_div">
        <form action="" method="POST" enctype="multipart/form-data">
            <?php
            include 'connection.php';
            if (isset($_POST['submit'])) {
                $username = $_SESSION['name'];
                $profile_img = $_SESSION['pimg'];
                $vid_desp = mysqli_real_escape_string($con, $_POST['ccdes']);
                $file = $_FILES['media'];
                $p_email = $_SESSION['pemail'];
                // print_r($file);
                $filename = $file['name'];
                $filepath = $file['tmp_name'];
                $fileerror = $file['error'];

                if ($fileerror == 0) {
                    $destpath = 'mainmedia/' . $filename;
                    move_uploaded_file($filepath, $destpath);
                    //same file present or not 
                    $checkname = "select * from main_content where video='$destpath'";
                    $checkquery = mysqli_query($con, $checkname);
                    $videocount = mysqli_num_rows($checkquery);

                    if ($videocount > 0) {
                        ?>
                        <script>
                            alert("same video is already present");
                        </script>
                        <?php
                    } else {
                        // username	profileimg	video	desp
                        $fileinsert = "insert into main_content(username,profileimg,video,desp,email) 
                        values('$username','$profile_img','$destpath','$vid_desp','$p_email')";
                        $iquery = mysqli_query($con, $fileinsert);
                        if ($iquery) {
                            ?>
                            <script>
                                alert("video uploaded");
                            </script>
                            <?php
                        } else {
                            ?>
                            <script>
                                alert("video not uploaded");
                            </script>
                            <?php
                        }
                    }
                } else {
                    ?>
            <script>
                alert("file error");
            </script>
            <?php
                }
            }

            ?>
            <!-- header -->
            <div class="nav_div">
                <div class="menu">
                    <ul>
                        <li><a href="#top">new-post</a></li>
                        <li class="comments"><a href="#">comments</a></li>
                        <li><a href="activeuse.php">active-user</a></li>
                        <li>
                            <a href="#">
                                <div class="profile" tooltip="profile" flow="down">
                                    <img src="<?php echo $_SESSION['pimg']; ?>" alt="profile_img">
                                </div>
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
            <!-- side bar -->
            <div class="sidebar">
                <div class="logo">
                    <a href="home.php">
                        <h2>ds Creation</h2>
                        <h3>ds</h3>
                    </a>
                </div>
                <div class="items">
                    <ul>
                        <li><a href="#"><i class="fa-solid fa-house"></i><span>home</span></a></li>
                        <li class="add_media"><a id="upload"><i
                                    class="fa-sharp fa-solid fa-circle-plus"></i><span>upload</span></a></li>
                        <li><a href="tel: +917319256047"><i class="fa-solid fa-phone-volume"></i><span>call us</span></a></li>
                        <li class="mail_me"><a href="#"><i class="fa-brands fa-square-twitter"></i><span>tweet</span></a>
                        </li>
                    </ul>
                </div>
                <div class="trademark">
                    <i class="fa-regular fa-copyright"></i>
                    <a href="https://www.instagram.com/radhedebu_321/" target="_blank">
                      debabrata_santra
                      <?php
                       $year = date("Y");
                       echo $year;
                      ?>
                     </a>
                </div>
            </div>

            <!-- profile box -->
            <div class="box active">
                <div class="heading" tooltip="profile name" flow="down">
                    <h2>Hi,
                        <?php 
                           $cemail = $_SESSION['pemail'];
                           $nameshow = "select * from demodata where email='$cemail'";
                           $namequery = mysqli_query($con, $nameshow);
                           $namedta = mysqli_fetch_array($namequery);
                           echo $namedta['name']; 
                        ?>
                    </h2>
                </div>
                <div class="sub_head">
                    <p>Welcome to Connect Verse...</p>
                </div>
                <div class="profile_image">
                    <img src="<?php echo $_SESSION['pimg']; ?>" alt="profile_image" class="dp_head">
                </div>
                <div class="lout">
                    <a href="logout.php" class="logout" tooltip="logout" flow="down">
                        <i class="fa fa-sign-out"></i>
                    </a>
                </div>
            </div>

            <!-- upload dialogue box -->
            <div class="upload_div">
                <div class="cancel_btn">
                    <i class="fa-solid fa-circle-xmark cancel_btn" id="ic"></i>
                </div>
                <div class="dia_head">create a new post</div>
                <div class="video_div">
                    <video id="img_area" autoplay></video>
                </div>
                <div class="icon_div">
                    <img src="md.png" alt="">
                </div>
                <div class="upload_btn">
                    <label for="fileinput">select from computer</label>
                </div>
                <input type="file" name="media" id="fileinput">
                <input type="text" name="ccdes" placeholder="video description" class="vid_des">
                <input type="submit" name="submit" value="upload" class="vid_upload">
            </div>

            <!-- main content -->
            <div class="main_content" id="top">
                <?php
                include 'connection.php';
                $showdata = "select * from main_content";
                $showquery = mysqli_query($con, $showdata);
                while ($arraydata = mysqli_fetch_array($showquery)) {
                    ?>
                    <div class="main_vids" >
                        <div class="video_d">
                           <a href="checkprofile.php?useremail=<?php echo $arraydata['email']?>">
                              <div class="user_img">
                                  <img src="<?php echo $arraydata['profileimg']; ?>" alt="">
                              </div>
                            </a>
                              <div class="username">
                                  <?php echo $arraydata['username']; ?>
                              </div>
                        </div>
                        <div class="content_video">
                            <video src="<?php echo $arraydata['video']; ?>" controls controlslist="nodownload nofullscreen"></video>
                        </div>
                        <div class="des"><span>
                                <?php echo $arraydata['username']; ?>
                            </span>
                            <?php echo $arraydata['desp']; ?>
                        </div>
                    </div>
                    <hr>
                    <?php
                }
                ?>
            </div>
        </form>

        <!-- maildiv -->
        <form action="" method="POST" enctype="multipart/form-data">
            <?php
            include 'connection.php';
            if (isset($_POST['mailsubmit'])) {
                $cname = $_SESSION['name'];
                $cimg = $_SESSION['pimg'];
                $cemail = $_SESSION['pemail'];
                $cmsg = mysqli_real_escape_string($con, $_POST['umsg']);
                $cmsgdate = date("d-m-y");

                $cmsginsert = "insert into mailtable(name,image,msg,email,msgdate) values('$cname','$cimg','$cmsg','$cemail','$cmsgdate')";
                $cinsertquery = mysqli_query($con, $cmsginsert);
                if ($cinsertquery) {
                    ?>
                    <script>
                        alert("msg sent");
                    </script>
                    <?php
                } else {
                    ?>
                    <script>
                        alert("msg not sent");
                    </script>
                    <?php
                }
            }
            ?>

            <div class="mail_div">
                <div class="head_part">Tweet across the whole world</div>
                <div class="form_div">
                    <div class="grp_div">
                        <textarea name="umsg" rows="8" placeholder="comment us" autocomplete="off" required></textarea>
                    </div>
                    <input type="submit" value="comment us" name="mailsubmit">
                </div>
            </div>

            <!-- show comment -->
            <div class="main_show_div1">
                <div class="heading_show1">users feddbacks</div>
                <hr>
                <?php
                include 'connection.php';
                $mailshow = "select * from mailtable";
                $mailshowquery = mysqli_query($con, $mailshow);
                while ($maildata = mysqli_fetch_array($mailshowquery)) {
                    ?>
                    <div class="show_content1">
                        <div class="subcon1">
                            <div class="profile_img1">
                                <img src="<?php echo $maildata['image'];?>" alt="demo img">
                            </div>
                            <div class="userdiv1">
                                <?php echo $maildata['name']; ?>
                            </div>
                        </div>
                        <div class="msg1">
                        <?php echo $maildata['msg']; ?> 
                            <span class="msgdate"><?php echo $maildata['msgdate']; ?></span>
                            <div class="icon_div">
                                <a href="update.php?id=<?php echo $maildata['id']; ?>"><i class="fa-regular fa-pen-to-square"></i></a>
                                <a href="delete.php?id=<?php echo $maildata['id']; ?>"><i class="fa-solid fa-trash"></i></a>
                            </div>
                        </div>
                    </div>
                    <?php
                }
                ?>
        </form>
    </div>



    <script src="https://smtpjs.com/v3/smtp.js"></script>
    <script>
        //profile div toggle
        const profilebtn = document.querySelector('.profile');
        const profilebox = document.querySelector('.box');

        profilebtn.onclick = () => {
            profilebox.classList.toggle('active');
        }
        // image file choose
        let imgfile = document.getElementById('fileinput');
        let imgarea = document.getElementById('img_area');
        let uploadbtn = document.querySelector('.upload_btn');
        let icon_div = document.querySelector('.icon_div');
        let dia_head = document.querySelector('.dia_head');
        const video_div = document.querySelector('.video_div');
        const vid_upload = document.querySelector('.vid_upload');
        const vid_des = document.querySelector('.vid_des');

        imgfile.addEventListener('change', (e) => {
            uploadbtn.style.display = 'none';
            icon_div.style.display = 'none';
            video_div.style.display = 'block';
            vid_upload.style.display = 'block';
            vid_des.style.display = 'block';

            if (e.target.files.length == 0) {
                return 0;
            }
            let tempurl = URL.createObjectURL(e.target.files[0]);
            imgarea.setAttribute("src", tempurl);
        });

        //----toggle to upload media box---//
        const add_media = document.querySelector('.add_media');
        const mediauploadbox = document.querySelector('.upload_div');
        const maindiv = document.querySelector('.main_div');
        add_media.onclick = () => {
            mediauploadbox.style.display = 'block';
            maindiv.classList.add('main_active');
        }

        const cancel_btn = document.querySelector('.cancel_btn');
        cancel_btn.onclick = () => {
            mediauploadbox.style.display = 'none';
            maindiv.classList.remove('main_active');
            location.reload();
        }

        // mail script
        const mail_me = document.querySelector('.mail_me');
        const mail_div = document.querySelector('.mail_div');

        mail_me.onclick = () => {
            mail_div.classList.toggle('mailactive');
        }

        const dp_head = document.querySelector('.dp_head');
        dp_head.onclick = () => {
            location.replace("profile.php");
            
        }

        //-----------------comments-----------------//
        let commentbtn = document.querySelector('.comments');
        let commentbox = document.querySelector('.main_show_div1');

        commentbtn.onclick = () => {
            commentbox.classList.toggle('showactive');
        }
        //for stroing date ipn comment
        let datedisplay = document.getElementById("ldate");
        let date = new Date().getDate();
        let month = new Date().getMonth();
        let year = new Date().getFullYear();

        console.log(date+"."+month+"."+year);

    </script>
</body>

</html>